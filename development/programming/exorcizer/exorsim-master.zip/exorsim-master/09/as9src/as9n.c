#include <stdio.h>
#include <string.h>
#define strncasecmp strncmp
#include "as.h"
#include "table9.h"
#include "as.c"
#include "do9.c"
#include "pseudo.c"
#include "eval.c"
#include "symtab.c"
#include "util.c"
#include "ffwd.c"
#include "output.c"
