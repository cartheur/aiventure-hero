package main

/*
Reference:
https://learn.adafruit.com/adafruit-ft232h-breakout/more-info

Because all the files are in the same directory you need to run "main.go" as
follows:
> go run .
or
> go run *

*/

var quit = false

func main() {
	drive_display()
}
