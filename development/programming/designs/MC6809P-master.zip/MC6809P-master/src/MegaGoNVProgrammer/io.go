package main

// An Address block. -- currently unused ---
type Block struct {
	// starting address
	address uint16
	data    []byte
}
