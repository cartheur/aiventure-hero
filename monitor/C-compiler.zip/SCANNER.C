/*--BEGIN PACKAGE--(scanner)----------------------------------------*/
/*
!	Hero Compiler Scanner	v1.0
!	Created : 19 Oct. 1993	(initial version)
!	Programmers : Charles Gedney, Richard England
!	Revision : (1) 15 Nov., 1993 added ProcessID_or_Hex
!	Version : 1.1
!
!	Scanner code for Micro compiler.  Returns token value.  Id 
!	and number tokens are placed in the token buffer.  The 
!	scanner package contains the global variables TokenBuffer 
!	and CurrentToken.
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<string.h>
#include	"hero.h"

static	int	ProcessID_or_HEX(int ch);
static	int	ProcessAddr(int ch);
static	int	CheckReserved(void);

char	TokenBuffer[NAME_LENGTH+1];
int	CurrentToken, Start, flag = 0;


/*--BEGIN FUNCTION--(NextToken)-------------------------------------
|								   |
|  This function checks for what type of character it is. The      |
|  appropriate function is called to handle each type.		   |
|								   |
-------------------------------------------------------------------*/

int 	NextToken(void)
{
int	ch, i;

for (i=0; i < NAME_LENGTH+1; i++)
TokenBuffer[ i ] = ' ';

if(Eof())	return (int) EOF_TOK;
while(!Eof())
	{
	ch = getch();
	if(isspace(ch))	continue;
	if(isalpha(ch))	return ProcessID_or_HEX(ch);
	if(isdigit(ch))	
		if(flag == 1)
			return ProcessID_or_HEX(ch);
		else
			return ProcessAddr(ch);
	switch(ch)
		{
		case '(':	return (int) LParen;
		case ')':	return (int) RParen;
		case '-':	/* handle comments */
			do
				ch = getch();
			while(ch != '\n');
			break;
		case -1:	return (int) EOF_TOK;
		default:	return (int) ERR_TOK;
		}
	}
return (int) EOF_TOK;
}
/*--END FUNCTION--(NextToken)---------------------------------------*/

/*--BEGIN FUNCTION--(ProcessID_or_HEX)------------------------------
|								    |
| This function builds a token buffer made up of alpha numeric      |
| characters							    |
|								    |
--------------------------------------------------------------------*/

static	int	ProcessID_or_HEX(int ch)
{
int	done, i;

for(done = FALSE, i = 0; i < NAME_LENGTH && !done; i++)
   {
	TokenBuffer[ i ] = (char) ch;
	ch = inspect( );
	if(isalpha(ch))
		advance( );
	else if (isdigit(ch))
		advance( );
	else
		done = TRUE;
    }

TokenBuffer[ i ] = '\0';
return CheckReserved( );
}
/*--END FUNCTION--(ProcessID_or_HEX)-------------------------------*/

/*--BEGIN FUNCTION--(CheckReserved)---------------------------------
|								    |
|  This function checks to see if the token created is a reserved   |
|  word.							    |
|								    |
--------------------------------------------------------------------*/

static	int	CheckReserved(void)
{
if(strcmp(TokenBuffer, "begin") == 0)
	return (int) BEGIN;
if(strcmp(TokenBuffer, "end") == 0)
	return (int) END;
if(strcmp(TokenBuffer, "head") == 0)
	return (int) HEAD;
if(strcmp(TokenBuffer, "wrist") == 0)
	return (int) WRIST;
if(strcmp(TokenBuffer, "arm") == 0)
	return (int) ARM;
if(strcmp(TokenBuffer, "gripper") == 0)
	return (int) GRIPPER;
if(strcmp(TokenBuffer, "move") == 0)
	return (int) MOVE;
if(strcmp(TokenBuffer, "say") == 0)
	return (int) SAY;
if(strcmp(TokenBuffer, "home") == 0)
	return (int) HOME;
if(strcmp(TokenBuffer, "left") == 0)
	return (int) LEFTRIGHT;
if(strcmp(TokenBuffer, "right") == 0)
	return (int) LEFTRIGHT;
if(strcmp(TokenBuffer, "extend") == 0)
	return (int) EXTRET;
if(strcmp(TokenBuffer, "retract") == 0)
	return (int) EXTRET;
if(strcmp(TokenBuffer, "rotate") == 0)
	return (int) ROTATE;
if(strcmp(TokenBuffer, "to") == 0)
	return (int) TO;
if(strcmp(TokenBuffer, "pivot") == 0)
	return (int) PIVOT;
if(strcmp(TokenBuffer, "raise") == 0)
	return (int) LOWERRAISE;
if(strcmp(TokenBuffer, "lower") == 0)
	return (int) LOWERRAISE;
if(strcmp(TokenBuffer, "forward") == 0)
	return (int) FORWARD;
if(strcmp(TokenBuffer, "backward") == 0)
	return (int) BACKWARD;
if(strcmp(TokenBuffer, "steer") == 0)
	return (int) STEER;
return (int) ID_or_HEXNUM;
}
/*--END FUNCTION--(CheckReserved)-----------------------------------*/

/*--BEGIN FUNCTION--(ProcessAddr)--------------------------------
|								    |
| This function builds a token buffer made up of numeric characters |
|								    |
--------------------------------------------------------------------*/

static	int	ProcessAddr(int ch)
{
int	done, i;

for(done = FALSE, i = 0; i < NAME_LENGTH && !done; i++)
    {
	TokenBuffer[ i ] = (char) ch;
	ch = inspect( );
	if(isdigit(ch))
		advance( );
	else
		done = TRUE;
     }
TokenBuffer[ i ] = '\0';
flag = 1;
return (int) ID_or_HEXNUM;
}
/*--END FUNCTION--(ProcessAddr)----------------------------------*/

/*--END PACKAGE--(scanner)------------------------------------------*/
