/*-----------------------(ASC-INT.C)------------------------------------
*       Programmers:    Charles A. Gedney Jr.
*                       Richard England
*       Project:        501 Hero Compiler
*       Start date:     19 Oct., 1993
*       Description:    converts ascii to integer, and integer to ascii
*       Revision #:     2
*       Revised:        (1) 14 Nov., 1993 added int to ascii converter
*                       (2) 22 Nov., 1993 Richard and I got the new int
*                       -hex functions working.
*-------------------------------------------------------------------
	Modules to convert ascii hex numbers to integers
	
	ascii_to_hex takes a single ascii char and converts it
		to an integer number.
	ascii_hex takes a char string and converts it to an int number.
	int_to_hex takes an integer number and coverts it to a single
		ascii character.
	int_ascii takes an integer number and converts it to a string of
		ascii characters.
	get_chksum takes an integer number and converts it to a two
		digit hex number.

*/
#define CHANGER
#include        <stdio.h>
#include        <stdlib.h>
#include        <string.h>
#include        <math.h>
#include        <ctype.h>
#include        <time.h>

int ascii_to_hex(char);
int ascii_hex(char *);
char int_to_hex(int);
char *int_ascii(int);
char *get_chksum(int);

int ascii_to_hex(char x)
{
int i;
x = toupper(x);
if ((x >= '0') && (x <= '9'))
	i = x -'0';
else if ((x >= 'A') && (x <= 'F'))
	i = x -'A' + 10;
else
	x = -1;
return i;
}

int ascii_hex(char *p)
{
int sum, junk;
sum = 0;

while (*p != '\0')
	{
	junk = ascii_to_hex(*p++);
	sum = sum*16 + junk;
	}
return sum;
}

char int_to_hex(int num)
{
 if (num <= 9)
	return (char)(num + '0');
 else if (num <=15)
	return (char)((num-10) + 'A');
 else
	{
	printf ("Why is this value %d\n",num);
	exit (0);
	}
}

char *int_ascii(int num)
{
int hold[3];
char *temp, b[5];


temp = (char *)malloc(strlen(b)+1);

if (num < 256) {
   hold[0] = num/16;
   hold[1] = num - (hold[0] * 16);
   b[0] = int_to_hex(0);
   b[1] = int_to_hex(0);
   b[2] = int_to_hex(hold[0]);
   b[3] = int_to_hex(hold[1]);
   b[4] = '\0';
   }
else {
   hold[0] = 1;
   hold[1] = num/16 - 16;
   hold[2] = num - (num/16 * 16);
   b[0] = int_to_hex(0);
   b[1] = int_to_hex(hold[0]);
   b[2] = int_to_hex(hold[1]);
   b[3] = int_to_hex(hold[2]);
   b[4] = '\0';
   }

strcpy(temp, b);
return temp;
}

char *get_chksum(int num)
{
int hold[2], i;
float j;
char *temp, chk[3];

temp = (char *)malloc(strlen(chk)+1);

if (num < 256) {
   hold[0] = num/16;
   hold[1] = num - (hold[0] * 16);
   chk[0] = int_to_hex(hold[0]);
   chk[1] = int_to_hex(hold[1]);
   chk[2] = '\0';
   }
else if (num < 512) {
   hold[0] = num/16 - 16;
   j = (float)num/16 - 16;
   hold[1] = (16*(1000*j - hold[0]*1000))/1000;
   chk[0] = int_to_hex(hold[0]);
   chk[1] = int_to_hex(hold[1]);
   chk[2] = '\0';
   }
else {
   hold[0] = num/32 - 16;
   i = num/16;
   j = (float)num/16;
   hold[1] = (16000*(j-i))/1000;
   chk[0] = int_to_hex(hold[0]);
   chk[1] = int_to_hex(hold[1]);
   chk[2] = '\0';
   }
strcpy(temp, chk);
return temp;
}
