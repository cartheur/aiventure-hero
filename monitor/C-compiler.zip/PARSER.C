/*--BEGIN PACKAGE--(MicroParser)-----------------------------------*/
/*
!       Hero Compiler Parser    v1.2
!       15 October, 1993        (initial version)
!
!       Parser for the Hero language as described in Crafting a 
!       Compiler.  It is based on version 1.0 of the Hero grammar.  
!       The parser uses consistent one token lookahead.
!
!       Positions (hexidecimal):
!                           extreme1        middle        extreme2        home
!       HEAD-------------------00-------------62-------------C2------------62
!       ARM EXTRET-------------00-------------4D-------------98------------00
!       ARM LOWERRAISE---------00-------------43-------------86------------00
!       WRIST ROTATE-----------00-------------4A-------------93------------4A
!       WRIST PIVOT------------00-------------52-------------A5------------00
!       GRIPPER----------------00-------------3A-------------75------------00
!       STEER------------------00-------------4A-------------93------------4A
*/

#define PARSER
#include        <stdio.h>
#include        <string.h>
#include        <stdlib.h>
#include        <ctype.h>
#include        <time.h>
#include        "hero.h"

FILE *tmp2, *tmp1, *fpsrc, *fpout;
int SuffixSupplied, Addr, St, count = 0;
char *SrcFile, *OutFile;
char *Phon;

static  void    init_IOP(char *);
static  void    Match(int token);
static  void    Program(void);
static  void    Statement(void);
static  void    MakeObject(void);
static  int     ProcessStart(void);

static int ch, Line;
static char cha[30], ju[4], ph[2];

/*--BEGIN FUNCTION--(main)----------------------------------*/

main(int argc, char *argv[])
{
long    stt;
int     i;
char    filen[20], outfilen[20];

if(argc != 2)
	{
	printf("\tUSAGE hc <source file> \n");
	return;
	}

stt = clock( );
printf("Hero Compiler   v1.1\n");

for (i=0; argv[1][i] != '\0'; i++) {
   filen[i] = argv[1][i];
   outfilen[i] = argv[1][i];
   if (argv[1][i] == '.')
	{
	filen[i] = '\0';
	outfilen[i] = '\0';
	}
   }
SrcFile = filen;
OutFile = outfilen;
strcat(SrcFile, ".hf");
strcat(OutFile, ".s19");

init_IOP(SrcFile);

printf("Compiling [%s] to [%s]\n", SrcFile, OutFile);

CurrentToken = NextToken();

/*  SYSTEM GOAL */
   Program( );
   Match(EOF_TOK);
/*              */

printf("%s has %d lines of code\n", SrcFile, count);

if(SyntaxErrors)
	printf("   [%d] Syntax errors\n", SyntaxErrors);
else
	{
	MakeObject();
	system("del tmp1");
	system("del tmp2");
	}
printf("done!  [%ld] ms CPU time\n", (clock( ) - stt)/1000);
}
/*--END FUNCTION--(main)-----------------------------------------*/

/*--BEGIN FUNCTION--(init_IOP)-----------------------------------*/
static void init_IOP (char *filename)
{
tmp1 = fopen("tmp1", "w");
tmp2 = fopen("tmp2", "w");
if((fpsrc = fopen(filename, "r" )) == NULL)
	{
	printf("[%s] could not be opened as source\n", filename);
	exit(1);
	}
ch = fgetc(fpsrc);
fflush(fpsrc);
}
/*--END FUNCTION--(init_IOP)-------------------------------------*/


/*--BEGIN FUNCTION--(MakeObject)-------------------------------*/

static  void    MakeObject()
{
FILE *out_file;
int i, j, k, m, chksum;
int junk;
char a[3], *jj;

fclose(tmp1);
fclose(tmp2);
if((tmp1 = fopen("tmp1", "r" )) == NULL)
	{
	printf("[tmp1] could not be opened\n");
	exit(1);
	}
if((tmp2 = fopen("tmp2", "r" )) == NULL)
	{
	printf("[tmp2] could not be opened\n");
	exit(1);
	}
if((out_file = fopen(OutFile, "w" )) == NULL)
	{
	printf("[%s] could not be opened\n", OutFile);
	exit(1);
	}

for (j=0; j<(Line+1); j++) {
/* scan tmp2 and get addresses */
   cha[0] = fgetc(tmp2);
   cha[1] = fgetc(tmp2);
   cha[2] = fgetc(tmp2);
   cha[3] = fgetc(tmp2);
/* throw away end-of-line character */
   junk = fgetc(tmp2);
fflush(tmp2);

/* get 13 or less hex numbers to add to record */
   for(i=4; i<28; i++) {
	   cha[i] = fgetc(tmp1);
	   fflush(tmp1);
	if (isxdigit(cha[i]))
	   ;
	else
	   break;
   }

   cha[i] = '\0';

/* compute actual number of hex nums received */
   m = (i+3) / 2;

/* compute checksum */
   chksum = 0;
   junk = 0;
   for(k=0; k<i;) {
	a[0] = cha[k++];
	a[1] = cha[k++];
	a[2] = '\0';
	junk = ascii_hex(a);
	chksum = chksum + junk;
   }
chksum = (chksum+m) % 256;
chksum = 255 - chksum;
jj = get_chksum(chksum);
printf("chksum = %d\n", chksum);

/* print S1, 0, hex representation of number received(0 -> F), hex 
stream of data, and checksum */
   fprintf(out_file, "S10%X%s%s\n", m, cha, jj);
   free(jj);
   fflush(out_file);
}

fprintf(out_file, "S9");

fflush(out_file);
fclose(out_file);
fflush(tmp1);
fclose(tmp1);
fflush(tmp2);
fclose(tmp2);
}
/*--END FUNCTION--(MakeObject)---------------------------------*/

/*--BEGIN FUNCTION--(getch)-------------------------------------------*/
int     getch(void)

{
int     c;

c = ch;
ch = fgetc(fpsrc);
fflush(fpsrc);
return c;
}
/*--END FUNCTION--(getch)-------------------------------------------*/

/*--BEGIN FUNCTION--(inspect)-----------------------------------------*/

int     inspect(void)
{
return ch;
}
/*--END FUNCTION--(inspect)----------------------------------------*/

/*--BEGIN FUNCTION--(advance)---------------------------------------*/

void    advance(void)
{
ch = fgetc(fpsrc);
fflush(fpsrc);

}
/*--END FUNCTION--(advance)------------------------------------------*/

/*--BEGIN FUNCTION--(Eof)------------------------------------*/
int Eof (void)
{
if (feof(fpsrc))
	return TRUE;
else
	return FALSE;
fflush(fpsrc);
}
/*--END FUNCTION--(Eof)------------------------------------------*/


/*--BEGIN FUNCTION--(Match)------------------------------------*/

static  void    Match(int token)
{
if(token != CurrentToken)
	{
	printf("ERROR on line :  %d\t", count);
	PrintToken(CurrentToken);
	printf(" does not match ");
	PrintToken(token);
	printf("\n");
	SyntaxErrors++;
	}

CurrentToken = NextToken( );
}
/*--END FUNCTION--(Match)--------------------------------------*/

/*--BEGIN FUNCTION--(Program)----------------------------------*/

static  void    Program(void)
{
char *jj;

Addr = ProcessStart();
jj = int_ascii(Addr);
fprintf(tmp2, "%s\n", jj);
fflush(tmp2);
free(jj);
fprintf(tmp1, "2007CE01000926FD39");
fflush(tmp1);
Addr = Addr + 10;
St = St + 10;
Match(ID_or_HEXNUM);
count++;
Statement( );
count++;

while((CurrentToken == (int) HEAD) || 
	(CurrentToken == (int) ARM) ||
	(CurrentToken == (int) HOME) ||
	(CurrentToken == (int) WRIST) ||
	(CurrentToken == (int) GRIPPER) ||
	(CurrentToken == (int) MOVE) ||
	(CurrentToken == (int) SAY)) {
	count++;
	Statement( );
	}
count++;
Match(END);
fprintf(tmp1,"3A");
fflush(tmp1);
}
/*--END FUNCTION--(Program)-------------------------------------*/


/*--BEGIN FUNCTION--(ProcessStart)------------------------------*/
static int ProcessStart(void)
{
int i;
   Match(BEGIN);
i = 2;
St = (int)TokenBuffer + i;
i = ascii_hex(TokenBuffer);
return i;
}
/*--END FUNCTION--(ProcessStart)---------------------------------*/

/*--BEGIN FUNCTION--(Statement)---------------------------------*/

static  void    Statement(void)
{
int i;
char junk, *junk2;

switch(CurrentToken)
	{
	case HOME:
		fprintf(tmp1, "FD"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "4D"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "62"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "4A"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(HOME);
		break;

	case HEAD:
		fprintf(tmp1, "C3"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(HEAD);
		fprintf(tmp1, "D0"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(LEFTRIGHT);
		fprintf(tmp1, "%s", TokenBuffer); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "BD"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "92"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		if (ascii_hex(TokenBuffer) > 194) {
		   printf("Head position %s out of range\n", TokenBuffer);
		   printf("Fully left =  00, Fully right = C2, HOME = 62\n");
		   SyntaxErrors++;
		   }
		Match(ID_or_HEXNUM);
		break;

	case ARM:
		fprintf(tmp1, "C3"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(ARM);
		if (CurrentToken == EXTRET) {
		   fprintf(tmp1, "30"); Addr = Addr + 1; St = St + 1;
		   fflush(tmp1);
		   if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			free(junk2);
			fflush(tmp2);
		   }
		   Match(EXTRET);
		   if (ascii_hex(TokenBuffer) > 152) {
		      printf("Ext/Ret position %s out of range\n", TokenBuffer);
		      printf("Fully Retracted = 00, Fully Extended = 98, HOME = 00\n");
		      SyntaxErrors++;
		      }
		   }
		else {
		   fprintf(tmp1, "48"); Addr = Addr + 1; St = St + 1;
		   fflush(tmp1);
		   if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		   }
		   Match(LOWERRAISE);
		   if (ascii_hex(TokenBuffer) > 134) {
		      printf("Lower/Raise position %s out of range\n", TokenBuffer);
		      printf("All the way down = 00, Up = 86, HOME = 00\n");
		      SyntaxErrors++;
		      }
		   }
		fprintf(tmp1, "%s", TokenBuffer); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "BD"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "92"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(ID_or_HEXNUM);
		break;

	case WRIST:
		fprintf(tmp1, "C3"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(WRIST);
		if (CurrentToken == ROTATE) {
		   fprintf(tmp1, "70"); Addr = Addr + 1; St = St + 1;
		   fflush(tmp1);
		   if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		   }
		   Match(ROTATE);
		   if (ascii_hex(TokenBuffer) > 147) {
		      printf("Rotate position %s out of range\n", TokenBuffer);
		      printf("Fully left = 00, Fully right = 93, HOME = 4A\n");
		      SyntaxErrors++;
		      }
		   }
		else {
		   fprintf(tmp1, "90"); Addr = Addr + 1; St = St + 1;
		   fflush(tmp1);
		   if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		   }
		   Match(PIVOT);
		   if (ascii_hex(TokenBuffer) > 165) {
		      printf("Pivot position %s out of range\n", TokenBuffer);
		      printf("Fully left = 00, Fully right = A5, HOME = 00\n");
		      SyntaxErrors++;
		      }
		   }
		fprintf(tmp1, "%s", TokenBuffer); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "BD"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "92"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(ID_or_HEXNUM);
		break;

	case GRIPPER:
		fprintf(tmp1, "C3"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(GRIPPER);
		fprintf(tmp1, "B0"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(TO);
		fprintf(tmp1, "%s", TokenBuffer); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "BD"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "92"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		if (ascii_hex(TokenBuffer) > 117) {
		   printf("Gripper position %s out of range\n", TokenBuffer);
		   printf("Fully closed = 00, Fully opened = 75, HOME = 00\n");
		   SyntaxErrors++;
		   }
		Match(ID_or_HEXNUM);
		break;

	case MOVE:
		fprintf(tmp1, "C3"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
			}
		Match(MOVE);
		if (CurrentToken == FORWARD) {
		   fprintf(tmp1, "10"); Addr = Addr + 1; St = St + 1;
		   fflush(tmp1);
		   if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
			}
		   Match(FORWARD);
		   }
		else if (CurrentToken == BACKWARD) {
		   fprintf(tmp1, "14"); Addr = Addr + 1; St = St + 1;
		   fflush(tmp1);
		   if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
			}
		   Match(BACKWARD);
		   }
		else {
		   fprintf(tmp1, "F0"); Addr = Addr + 1; St = St + 1;
		   fflush(tmp1);
		   if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
			}
		   Match(STEER);
		   if (ascii_hex(TokenBuffer) > 147) {
		      printf("Steering position %s out of range\n", TokenBuffer);
		      printf("Full left = 00, Full right = 93, HOME = 4A\n");
		      SyntaxErrors++;
		      }
		   }
		fprintf(tmp1, "%s", TokenBuffer); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "BD"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "00"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		fprintf(tmp1, "92"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(ID_or_HEXNUM);
		break;

	case SAY:
		fprintf(tmp1, "72"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		i = Addr + 4;
		junk2 = int_ascii(i);
		fprintf(tmp1, "%s", junk2);
		fflush(tmp1);
		free(junk2);
		St = St + 1;
		Addr = Addr + 1;
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		St = St + 1;
		Addr = Addr + 1;
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		Match(SAY);
		Match(LParen);
		Phon =findphon(TokenBuffer);
		ph[0]=*Phon++;
		ph[1]=*Phon++;
		ph[2]='\0';
		Phon++;
		fprintf(tmp1, "7E"); Addr = Addr + 1; St = St + 1;
		fflush(tmp1);
		i = Addr + 3;
		i = i + ascii_hex(ph);
		junk2 = int_ascii(i);
		fprintf(tmp1, "%s", junk2);
		fflush(tmp1);
		free(junk2);
		St = St + 1;
		Addr = Addr + 1;
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		St = St + 1;
		Addr = Addr + 1;
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		}
		i = 0;
		for (i=0; Phon[i] != '\0'; i++) {
		   ph[0] = Phon[i++];
		   ph[1] = Phon[i++];
		   junk = Phon[i];
		   fprintf(tmp1, "%s",ph); Addr = Addr + 1; St = St + 1;
		   fflush(tmp1);
		   if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
		   }
		}
		free(Phon);
/*  need to create library and open it here  */
		fprintf(tmp1, "3F");
		fflush(tmp2);
		Addr = Addr + 1;   St = St + 1;
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
			}
			
		fprintf(tmp1, "FF");
		fflush(tmp1);
		Addr = Addr + 1;   St = St + 1;
		if (St > 11) {
			Line++;
			St = 0;
			junk2 = int_ascii(Addr + 1);
			fprintf(tmp2, "%s\n", junk2);
			fflush(tmp2);
			free(junk2);
			}
		Match(ID_or_HEXNUM);
		Match(RParen);
		break;

	default:        SyntaxError(
		"Not statement starter");
	}
}
/*--END FUNCTION--(Statement)------------------------------------*/


/*--END PACKAGE--(MicroParser)--------------------------------------*/

