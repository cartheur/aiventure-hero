#define UTIL
#include <stdio.h>
#include "hero.h"

/*--BEGIN FUNCTION--(PrintLexeme)--------------------------------*/
void    PrintLexeme(int token)
{
switch(token)
	{
	case LParen:    printf("(");    break;
	case RParen:    printf(")");    break;
	case EOF_TOK:   printf("EofSym");       break;
	case NUL_TOK:   printf("NulSym");       break;
	case ID_or_HEXNUM:      printf("%s", TokenBuffer);      break;
	case START:     printf("%s", TokenBuffer);      break;
	case BEGIN:     printf("begin");        break;
	case END:       printf("end");  break;
	case ARM:       printf("arm"); break;
	case FORWARD:   printf("forward"); break;
	case GRIPPER:   printf("gripper"); break;
	case EXTRET:    printf("extend or retract Sym"); break;
	case HEAD:      printf("head"); break;
	case HOME:      printf("home"); break;
	case LEFTRIGHT: printf("left or right Sym"); break;
	case LIGHT:     printf("light"); break;
	case LISTEN:    printf("listen"); break;
	case LOOK:      printf("look"); break;
	case LOWERRAISE:        printf("lower or raise Sym"); break;
	case MOTION:    printf("motion"); break;
	case MOVE:      printf("move"); break;
	case TO:        printf("to"); break;
	case PIVOT:     printf("pivot"); break;
	case ROTATE:    printf("rotate"); break;
	case STEER:     printf("steer"); break;
	case SAY:       printf("speech"); break;
	case WRIST:     printf("wrist"); break;
	default:        printf("Unassigned Token");     break;
	}
}
/*--END FUNCTION--(PrintLexeme)-------------------------------------*/

/*--BEGIN FUNCTION--(PrintToken)------------------------------------*/
/*
!       Function to print the token symbol.
*/
void    PrintToken(int token)
{
switch(token)
	{
	case LParen:    printf("LParen");       break;
	case RParen:    printf("RParen");       break;
	case EOF_TOK:   printf("EOF_TOK");      break;
	case ID_or_HEXNUM:   printf("ID_or_HEXNUM");     break;
	case BEGIN:     printf("BEGIN");        break;
	case BACKWARD:  printf("BACKWARD");     break;
	case END:       printf("END");          break;
	case ERR_TOK:   printf("ERR_TOK");      break;
	case FORWARD:   printf("FORWARD");      break;
	case START:     printf("START");        break;
	case ARM:       printf("ARM");          break;
	case GRIPPER:   printf("GRIPPER");      break;
	case EXTRET:    printf("EXTRET");       break;
	case HEAD:      printf("HEAD");         break;
	case HOME:      printf("HOME");         break;
	case LEFTRIGHT: printf("LEFTRIGHT");    break;
	case LIGHT:     printf("LIGHT");        break;
	case LISTEN:    printf("LISTEN");       break;
	case LOOK:      printf("LOOK");         break;
	case LOWERRAISE:     printf("LOWERRAISE");       break;
	case MOTION:    printf("MOTION");       break;
	case MOVE:      printf("MOVE");         break;
	case TO:        printf("TO");           break;
	case PIVOT:     printf("PIVOT");        break;
	case ROTATE:    printf("ROTATE");       break;
	case SAY:       printf("SAY");          break;
	case STEER:     printf("STEER");        break;
	case TURN:      printf("TURN");         break;
	case WRIST:     printf("WRIST");        break;
	default:        printf("Unassigned Token");       break;
	}
}
/*--END FUNCTION--(PrintToken)---------------------------------------*/

/*--BEGIN FUNCTION--(PrintType)--------------------------------------*/
char    *PrintType(int type)
{
char    *cp;

switch(type)
	{
	case 0: cp = "Symbol";  break;
	case 1: cp = "Identifier";      break;
	case 2: cp = "Temporary";       break;
	case 3: cp = "Literal"; break;
	case 4: cp = "Register";        break;
	default:        cp = "Unassigned Type"; break;
	}
return cp;
}
/*--END FUNCTION--(PrintType)-----------------------------------------*/
/*--END PACKAGE--(UtilityRoutines)-----------------------------------*/
