/*--BEGIN PACKAGE--(Speech)---------------------------------*/
/*
!       Speech Package for Hero v1.0
!       17 November 1993 (initial version)
*/
/*
!       Define char *findphon(char *word) in hero.h
!       Use that function to get the string you want.
*/

#include        <stdio.h>
#include        <stdlib.h>
#include        <string.h>
#include        <ctype.h>
#include        "hero.h"

#define SPEECH
#define and &&

FILE *err;

char *findphon(char *word)
{
int found,i;
char buffer[100];
char buffer2[25];
FILE *phon;
char c,*temp;

found = 0;
phon = fopen ("phon.txt", "r");
strcpy(buffer2,word);

i=0;
while (buffer2[i] != '\0')
	{
	buffer2[i] = tolower(buffer2[i]);
	i++;
	}

i=0;
while ((found == 0) and (!feof(phon)))
	{
	while (((c=getc(phon)) != ' ') and (!feof(phon)))       
		{
		fflush(phon);
		buffer[i] = c;
		i++;
		}
	buffer[i] = '\0';
	i=0;
	if(strcmp(buffer,buffer2) == 0)
		{
		found = 1;
		while (((c=getc(phon)) != '\n') and (!feof(phon)))
			{
			fflush(phon);
			buffer[i++]=c;
			}
		buffer[i]='\0';
		}
	else
		{
		while (((c=getc(phon)) != '\n') and (!feof(phon)))
			fflush(phon);
		}
	}
fclose(phon);
if (found == 1)
	{
	temp =  (char *)malloc(strlen(buffer)+1);
	strcpy (temp,buffer);
	return (temp);
	}
else
	{
	return (" ");
	}
}
