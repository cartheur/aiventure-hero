/*-----------------------(ERROR.C)-----------------------------------
*       Programmers:    Charles A. Gedney Jr.
*                       Richard England
*       Project:        501 Hero Compiler
*       Start date:     19 Oct., 1993
*       Description:    handles syntax errors
*       Revision #:     
*       Revised:        
*-------------------------------------------------------------------*/
#define ERRORPKG
#include        <stdio.h>
#include        "hero.h"

int     SyntaxErrors = 0;

/*--BEGIN FUNCTION--(SyntaxError)-----------------------------------*/
/*
!       Function to create syntax error message.
*/

void    SyntaxError(char *string)
{
printf("SYNTAX ERROR:  %s\n", string);
SyntaxErrors++;
}

/*--END FUNCTION--(SyntaxError)--------------------------------------*/

/*--END PACKAGE--(ErrorPackage)------------------------------------*/
